﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MyFristProject
{
    /// <summary>
    /// Interaction logic for playScreen.xaml
    /// </summary>
    public partial class playScreen : Window
    {
        public playScreen()
        {
            InitializeComponent();
        }
        static int score;
        private void Btn1_Click(object sender, RoutedEventArgs e)
        {
            int a, b, c, d;
            Random r = new Random();
            a = r.Next(10);
            b = r.Next(50);
            c = r.Next(10);
            d = r.Next(50);
            btn1.Margin = new Thickness(a,b,c,d);
            score++;
            lblscore.Content = score.ToString();
        }
    }
}
