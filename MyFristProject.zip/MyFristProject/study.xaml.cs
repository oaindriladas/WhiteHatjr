﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Diagnostics;
using System.Threading;

namespace MyFristProject
{
    /// <summary>
    /// Interaction logic for study.xaml
    /// </summary>
    public partial class study : Window
    {
        public study()
        {
            InitializeComponent();
        }
        Stopwatch s = new Stopwatch();
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            s.Start();

            // Do something.
            for (int i = 0; i < 1000; i++)
            {
                Thread.Sleep(1);
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            s.Stop();
            lbldisplay.Content = s.Elapsed.ToString();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            s.Reset();
            lbldisplay.Content = "";
        }
    }
}
